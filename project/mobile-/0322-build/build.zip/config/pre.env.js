'use strict'
module.exports = {
  NODE_ENV: '"preproduction"',
  HTTPS_WXSNS: '/wxSns/',
  HTTPS_ZDAPIS: '/zdApis/'
}
