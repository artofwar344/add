'use strict'
module.exports = {
  NODE_ENV: '"production"',
  HTTPS_WXSNS: '/wxSns/',
  HTTPS_ZDAPIS: '/zdApis/'
}
